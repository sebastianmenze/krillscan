#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Correct triangle noise wave in ES60 data

Created on Wed May  2 10:30:23 2018
@author: Alejandro Ariza, British Antarctic Survey
"""

def correct_es60triangle(Sv):
    
    print('TODO')