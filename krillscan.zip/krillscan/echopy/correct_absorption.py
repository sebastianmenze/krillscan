#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Correct Sv data for new water absorption coefficient

Created on Fri Apr 27 14:39:37 2018
@author: Alejandro Ariza, British Antarctic Survey
"""

def correct_absorption(Sv, r, T, S):
    
    print('TODO')