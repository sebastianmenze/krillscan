#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Correct Sv data for new sound speed

Created on Fri Apr 27 14:37:56 2018
@author: Alejandro Ariza, British Antarctic Survey
"""

def correct_soundspeed(Sv, r, T, S):
    
    print('TODO')